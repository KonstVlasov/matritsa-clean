yii2-dynamicform change Log
===========================

dev-master
----------


version 2.0.2
-------------
**Date:** 25-Fev-2015
- bug #22: Correct reset attributes (id, name) when we have more than two nested widgets 


version 2.0.1
-------------
**Date:** 23-Fev-2015
- bug: Fixed error for the use of multiple nested widgets with zero initial elements


version 2.0.0
-------------
**Date:** 22-Fev-2015
- enh #20: Added trigger 'beforeDelete'
- bug #19: Fixes checkboxes on new items
- enh #15: Added support for multiple nested widgets


version 1.1.0
-------------
**Date:** 16-Dez-2014

- bug #7: Added support for "kartik-v/yii2-widget-depdrop" for working with type DepDrop::TYPE_SELECT2
- bug #8: Fixes to support the latest version of kartik-v widgets
- bug: Fixed client validation
- bug #6: Fixed settings for datepicker
- enh: Added support for "kartik-v/yii2-widget-depdrop"
- enh: Added support for "kartik-v/yii2-widget-select2"
- bug: Fixed html name attribute for "kartik-v/yii2-widget-colorinput"
- enh: Added support for "kartik-v/yii2-widget-timepicker"
- enh: Added support for "kartik-v/yii2-widget-colorinput"


version 1.0.0
-------------
**Date:** 05-Nov-2014

Initial release
