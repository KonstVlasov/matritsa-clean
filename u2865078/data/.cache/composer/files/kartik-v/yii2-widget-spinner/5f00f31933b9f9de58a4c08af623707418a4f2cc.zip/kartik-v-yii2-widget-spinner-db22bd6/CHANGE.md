Change Log: `yii2-widget-depdrop`
=================================

## Version 1.0.1

**Date:** 09-Oct-2018

- Bump composer dependencies.
- Add Bootstrap 4.x support.
- Reorganize all source code in `src` directory.
- Add github contribution and issue/PR log templates.
- Update copyright year to current.

## Version 1.0.0

**Date:** 08-Nov-2014

- Initial release 
- Sub repo split from [yii2-widgets](https://github.com/kartik-v/yii2-widgets)