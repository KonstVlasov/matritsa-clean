Change Log: `yii2-widget-sidenav`
=================================

version 1.0.2
=============

**Date:** 07-Sep-2021

- (enh #11): Enhancements to support Bootstrap v5.x.

version 1.0.1
=============

**Date:** 08-Apr-2021

- (enh #10): Enhance to work with Bootstrap 4.x. 
- (bug #9): Fix demo site.
- (bug #3): Enhance `linkTemplate` to be overridden correctly.

version 1.0.0
=============

**Date:** 08-Nov-2014

- Initial release 
- Sub repo split from [yii2-widgets](https://github.com/kartik-v/yii2-widgets)