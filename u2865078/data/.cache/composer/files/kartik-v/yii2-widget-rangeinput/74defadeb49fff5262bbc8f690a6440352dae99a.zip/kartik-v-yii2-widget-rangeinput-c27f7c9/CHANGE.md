Change Log: `yii2-widget-rangeinput`
====================================

## Version 1.0.2

**Date:** 07-Sep-2018

- Add github contribution and issue/PR log templates.
- Update to include Bootstrap 4.x support
- Reorganize source code into `src` directory

## Version 1.0.1

**Date:** 22-Nov-2015

- Update HTML5 input initialization

## Version 1.0.0

**Date:** 08-Nov-2014

- Initial release 
- Sub repo split from [yii2-widgets](https://github.com/kartik-v/yii2-widgets)