Change Log: `yii2-widget-alert`
===============================

## Version 1.1.3

**Date:** 28-Oct-2021

- Enhancements to support Bootstrap v5.x.

## Version 1.1.2

**Date:** 19-May-2021

- (enh #6): Change `Growl::$_settings` var from private to protected.
- Enhancements to support both Bootstrap 4.x & 3.x.
- Move all source code to `src` directory.

## Version 1.1.1

**Date:** 03-May-2015

- enh #4: Upgrade extension to use latest release & features of bootstrap-notify plugin.

## Version 1.1.0

**Date:** 10-Nov-2014

- bug #1: Correct AnimateAsset dependency
- set stability to stable


## Version 1.0.0

**Date:** 08-Nov-2014

- Initial release 
- Sub repo split from [yii2-widgets](https://github.com/kartik-v/yii2-widgets)