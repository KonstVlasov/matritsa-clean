Not a headline but a code block:

```
---
```

Not a headline but two HR:

***
---

---
***

