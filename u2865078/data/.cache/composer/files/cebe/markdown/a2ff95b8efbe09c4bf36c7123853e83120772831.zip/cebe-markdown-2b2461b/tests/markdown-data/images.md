![Total Downloads](https://poser.pugx.org/cebe/markdown/downloads.png)
![Build Status](https://secure.travis-ci.org/cebe/markdown.png "test1")

Here is an image tag: ![Total Downloads](https://poser.pugx.org/cebe/markdown/downloads.png).

Images inside of links:
[![Total Downloads](https://poser.pugx.org/cebe/markdown/downloads.png)](https://packagist.org/packages/cebe/markdown)
<!-- [![Scrutinizer Quality Score](https://scrutinizer-ci.com/g/cebe/markdown/badges/quality-score.png?s=17448ca4d140429fd687c58ff747baeb6568d528)](https://scrutinizer-ci.com/g/cebe/markdown/) -->
[![Build Status](https://secure.travis-ci.org/cebe/markdown.png "test2")](http://travis-ci.org/cebe/markdown)
[![Build Status](https://secure.travis-ci.org/cebe/markdown.png "test3")](http://travis-ci.org/cebe/markdown "test4")

This is not an image: ![[ :-)

This is not an image: ![[ :-)]]

![Alt text](/path/to/img.jpg)

![Alt text]( /path/to/img.jpg)

![Alt text]( /path/to/img.jpg  )

![Alt text](/path/to/img.jpg  )