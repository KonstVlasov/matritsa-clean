In the following example we will im[ple]ment support for [fenced code blocks][] which are part
of the [github flavored markdown][gfm].

[fenced code blocks]: https://help.github.com/articles/github-flavored-markdown#fenced-code-blocks
                      "Fenced code block feature of github flavored markdown"
[gfm]: https://github.com
[unused]: https://github.com/unused

hey, check [this].

[this]: https://github.com/cebe/markdown

ref on end of line [this]
next line.

this is a [multi
line] reference.

this is a [Link
with][multi
line] reference.

[multi line]: http://example.com

[ ]

[not a] reference