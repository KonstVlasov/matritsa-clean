this is ~~striked out~~ after

~~striked out~~

a line with ~~ in it ...

~~

~