this is `inline code`

this is ``inline code``

this is `` inline code ``

this is `` inline ` code ``

this is ``` inline `` code ```

    code block

    code block

this is code too: ` co
ooo
de `

A code block enclosed in brackets: [`somecode`].

A code block enclosed in brackets: [ `somecode` ].

A code block enclosed in a link: [`somecode`](./url.md).

A code block enclosed in image brackets: ![`somecode`].

A code block enclosed in image brackets: ![ `somecode` ].
