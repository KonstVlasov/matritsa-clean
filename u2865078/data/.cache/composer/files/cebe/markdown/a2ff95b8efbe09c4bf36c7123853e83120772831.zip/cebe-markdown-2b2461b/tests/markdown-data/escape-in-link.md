nice [video](http://www.youtube.com/video\-on\e). Nice\-vide\o star \*

nice ![video](http://www.youtube.com/video\-on\e). Nice\-vide\o star \*

[video]: http://www.youtube.com/video\-on\e

[video] and <http://www.youtube.com/video\-on\e> and <m\a\-il@cebe.cc>
