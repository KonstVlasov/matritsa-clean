GitHub Flavored Markdown
========================

Multiple underscores in words
-----------------------------

do_this_and_do_that_and_another_thing

URL autolinking
---------------

http://example.com

Strikethrough
-------------

~~Mistaken text.~~

Fenced code blocks
------------------

```
function test() {
  console.log("notice the blank line before this function?");
}
```

Syntax highlighting
-------------------

```ruby
require 'redcarpet'
markdown = Redcarpet.new("Hello World!")
puts markdown.to_html
```

~~~
this is also code
~~~

