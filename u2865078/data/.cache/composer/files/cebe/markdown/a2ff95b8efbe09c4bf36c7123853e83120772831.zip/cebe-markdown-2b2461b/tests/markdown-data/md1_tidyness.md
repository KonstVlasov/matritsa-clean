> A list within a blockquote:
> 
> *	asterisk 1
> *	asterisk 2
> *	asterisk 3
