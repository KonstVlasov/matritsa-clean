Instalación
===========

## Obteniendo el Paquete de Composer

La mejor manera para instalar esta extensión es a través de [composer](https://getcomposer.org/download/).

Ejecuta

```
php composer.phar require --prefer-dist yiisoft/yii2-bootstrap5
```

o añade

```
"yiisoft/yii2-bootstrap": "~1.0.0"
```

en la sección require de tu fichero `composer.json`.
